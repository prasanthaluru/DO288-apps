
USE mysql;

DROP DATABASE IF EXISTS todo;
DROP USER 'todoapp'@'localhost';
DROP USER 'todoapp'@'%';

